//!Selectors

const todoInput = document.querySelector(".todo-input");
const todoBtn = document.querySelector(".todo-btn");
const todoList = document.querySelector(".todo-list");
const filterOptions = document.querySelector(".filter-todo");

//!Event Listeners

todoBtn.addEventListener("click", (e) => {
  //prevent form from submition "default behavior"
  e.preventDefault();

  //creating the div => holds li & 2 buttons
  const todoDiv = document.createElement("div");
  todoDiv.classList.add("todo");

  //creating the li "todo"
  const newTodo = document.createElement("li");
  newTodo.innerText = todoInput.value;
  newTodo.classList.add("todo-item");
  todoDiv.appendChild(newTodo);

  //saving to local storage
  saveLocalTodos(todoInput.value);

  //to prevent text sticking in the input after submission
  todoInput.value = "";

  //creating the complete button
  const completedBtn = document.createElement("button");
  completedBtn.classList.add("completed-btn");

  //we are using font-awsome cdn for our icons
  completedBtn.innerHTML = `<i class="fas fa-check"></i>`;
  todoDiv.appendChild(completedBtn);

  //creating the trash button
  const trashBtn = document.createElement("button");
  trashBtn.classList.add("trash-btn");
  trashBtn.innerHTML = `<i class="fas fa-trash"></i>`;
  todoDiv.appendChild(trashBtn);

  //append the todo to the "ul"
  todoList.appendChild(todoDiv);
});

const deleteTodo = (e) => {
  const item = e.target;
  //delete
  if (item.classList[0] === "trash-btn") {
    const todo = item.parentElement;
    todo.classList.add("drop");

    removeLocalTodos(todo);
    todo.addEventListener("transitionend", (e) => {
      todo.remove();
    });
  }
  //check
  if (item.classList[0] === "completed-btn") {
    const todo = item.parentElement;
    todo.classList.toggle("completed");
  }
};
todoList.addEventListener("click", deleteTodo);

//!filter

filterOptions.addEventListener("click", (e) => {
  const todos = todoList.childNodes;

  todos.forEach((todo) => {
    switch (e.target.value) {
      case "all":
        todo.style.display = "flex";
        break;
      case "completed":
        if (todo.classList.contains("completed")) {
          todo.style.display = "flex";
        } else {
          todo.style.display = "none";
        }
        break;
      case "uncompleted":
        if (todo.classList.contains("completed")) {
          todo.style.display = "none";
        } else {
          todo.style.display = "flex";
        }
        break;
    }
  });
});

//!local storage

const saveLocalTodos = (todo) => {
  let todos;
  if (localStorage.getItem("todos") === null) {
    todos = [];
  } else {
    todos = JSON.parse(localStorage.getItem("todos"));
  }
  todos.push(todo);
  localStorage.setItem("todos", JSON.stringify(todos));
};

//!display todos back from storage

const gettodos = () => {
  let todos;
  if (localStorage.getItem("todos") === null) {
    todos = [];
  } else {
    todos = JSON.parse(localStorage.getItem("todos"));
  }
  todos.forEach((todo) => {
    const todoDiv = document.createElement("div");
    todoDiv.classList.add("todo");
    const newTodo = document.createElement("li");
    newTodo.innerText = todo;
    newTodo.classList.add("todo-item");
    todoDiv.appendChild(newTodo);
    const completedBtn = document.createElement("button");
    completedBtn.classList.add("completed-btn");
    completedBtn.innerHTML = `<i class="fas fa-check"></i>`;
    todoDiv.appendChild(completedBtn);
    const trashBtn = document.createElement("button");
    trashBtn.classList.add("trash-btn");
    trashBtn.innerHTML = `<i class="fas fa-trash"></i>`;
    todoDiv.appendChild(trashBtn);
    todoList.appendChild(todoDiv);
  });
};

document.addEventListener("DOMContentLoaded", gettodos);

//!remove position from localstorage

const removeLocalTodos = (todo) => {
  let todos;
  if (localStorage.getItem("todos") === null) {
    todos = [];
  } else {
    todos = JSON.parse(localStorage.getItem("todos"));
  }
  const todoIndex = todo.children[0].innerText;
  todos.splice(todos.indexOf(todoIndex), 1);
  localStorage.setItem("todos", JSON.stringify(todos));
};
